const mysql = require('mysql');
const express = require('express');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'Movie'
});
app.use(express.static('.'))
connection.connect((err) => {
  if (err) 
    console.log("error");
  console.log('Connected to MySQL database!');
});
app.get('/', function (req, res) 
{
res.sendFile(__dirname + '/index.html')
})

app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;np

  connection.query('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (error, results, fields) => {
    if (error) throw error;

    if (results.length > 0) {
      res.send('Login successful!');
    } else {
      res.send('Invalid username or password');
    }
  });
});

app.listen(8080, () => {
  console.log('Server running on port 3000');
});
